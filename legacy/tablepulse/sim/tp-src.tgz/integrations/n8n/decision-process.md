# How TablePulse decides a deal

Think of the current decision maker as a manager with a checklist and a scoring sheet. It is rules-based software, not a language-model agent. Every event has a recorded reason, including when nothing is shown.

1. **Wait for a genuine new order.** Waiting, signing in, scanning a QR or requesting a check-in code does not trigger a reward. n8n only forwards accepted new POS orders.
2. **Apply the non-negotiable rules.** An open bill must have a qualifying organic order, no other discounts and no staff block. Live rewards need a verified customer. A table cannot receive a second reward; a customer cannot hold another active reward at another table or redeem a subsidy within 30 days. A campaign cannot repeat for the same customer within 60 days.
3. **Find useful add-ons.** Two mains without drinks can match a drink pairing; two beers without snacks can match a snack. A main plus one glass of wine may match the configured bottle campaign. An opted-in member's unused entitlement can match only after a new qualifying purchase. The offered item must not already be ordered.
4. **Protect stock, safety and profit.** Remove out-of-stock, disabled, capped and unsafe campaigns. Alcohol offers require staff verification that all recipients are 18+ and not flagged intoxicated. The selected item's potential additional gross profit, `(offer price − item cost) × quantity`, must strictly exceed the venue's threshold.
5. **Score and sometimes withhold.** Score eligible candidates, require a score strictly above the configured threshold, then apply probabilistic allocation. Choose the highest-scoring remaining candidate only if allocation passes. A control visit shows no reward.
6. **Lock the opportunity and recheck redemption.** Once a safe, profitable basket match is considered, the visit's opportunity is consumed even when score or random allocation withholds it. Another order, account link or staff override cannot reroll it. The backend rechecks the current bill, qualifying items, code, expiry, customer cap, stock, margin and alcohol safety at redemption.

## Current scoring sheet

| Component                         | Implemented calculation                                                                 | Maximum points |
| --------------------------------- | --------------------------------------------------------------------------------------- | -------------- |
| Basket relevance                  | A campaign must match its configured basket rule; a match receives 28 points.           | 28             |
| Optional category preference      | Add 2 when the member has opted in and likes the offered item's category.               | 2              |
| Potential additional gross profit | `min(25, gross profit / 20 × 25)` in SGD.                                               | 25             |
| Inventory                         | `min(15, stock / offer quantity / 3)`.                                                  | 15             |
| Frequency                         | 10 after customer caps pass; a failed cap is rejected, not compensated by other scores. | 10             |
| Campaign priority                 | Venue priority (0–100) divided by 10.                                                   | 10             |
| Random factor                     | Cryptographic random value from 0 to just below 10.                                     | <10            |

Defaults: gross-profit threshold **S$2.50**, score threshold **65**, allocation probability **78%**, and control assignment **15%** when a visit opens. The score is a ranking heuristic, not a probability that someone will buy. These defaults are editable in the manager dashboard. V1 considers stock but does not reserve physical inventory per offer; it rechecks stock on display/redemption.

For a snack offered at S$3.90 with a S$1.20 item cost, the item would contribute S$2.70 gross profit if bought. It passes a S$2.50 item-profit threshold. It can still be withheld by score, random allocation, customer caps or safety checks. Operating costs, taxes, cannibalisation and purchases that would have happened anyway are not fully captured by that item calculation. Compare offer tables with matched control tables to estimate actual uplift before increasing budgets; the current engine does not predict counterfactual spending.

## What customer memory does today

A stable customer UUID joins the account to staff-confirmed visits, associated table orders, preferences and reward history. The permanent membership number is a reference, not a password. Raw phone data stays in Supabase Auth. Shared-table orders are not proof of an individual's consumption.

The engine currently uses history for reward caps, repeat-campaign suppression and the unused return entitlement. Preferences make a small scoring contribution when opted in. It does not yet learn “this person usually buys a third beer” or forecast the best personalised offer from purchase history.

A later recommendation model can estimate which **already approved** offer is likely to add gross profit, with `NO_OFFER` among the choices. It must never bypass the hard rules or generate arbitrary prices/items. Train from opted-in, correctly attributed data and measured control results; evaluate changes before allowing live allocation. No paid AI service is required for the current MVP.

## Exploit controls and remaining limits

- Stable event IDs and atomic commits stop duplicate webhook deliveries from generating extra stock deductions or reward attempts.
- Staff confirms attendance using a short-lived, one-use table check-in code; a screenshot of the public QR does not establish identity.
- A withheld profitable opportunity stays consumed, and customer active-reward checks apply across this venue's table visits.
- Redemption stays bound to the current bill and original qualifying items, with failed attempts logged.

Phone OTP proves possession of a number, not a unique person. Multiple phone accounts, account sharing, recycled numbers and staff collusion remain possible. A real POS adapter must preserve visit identity through table moves, bill splits and reopen events. V1 caps are venue-scoped and nominally one linked member per table; it does not recognise every person in a party. Use conservative allocations and investigate audit patterns during the pilot. “Impossible to exploit” would be an inaccurate promise.
