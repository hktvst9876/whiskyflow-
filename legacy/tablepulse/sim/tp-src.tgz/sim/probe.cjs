const { PGlite } = require("@electric-sql/pglite");
(async()=>{const db=new PGlite();const r=await db.query(`select '[{"menuItemId":"abc","quantity":1}]'::jsonb as j`);console.log(JSON.stringify(r.rows[0].j));await db.close();})();
